package com.aitrendmaker.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.aitrendmaker.model.ProcessingState
import com.aitrendmaker.model.TrendTemplateRepository
import com.aitrendmaker.util.VideoProcessor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ProcessingViewModel @Inject constructor(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val state: StateFlow<ProcessingState> = _state.asStateFlow()

    private val context get() = getApplication<Application>().applicationContext

    /**
     * Begin beat-sync processing.
     * [mediaUris] and [isVideoList] are passed directly from the EditorViewModel's
     * selected media (shared via the backstack using SavedStateHandle in a full DI setup,
     * or passed here from the screen directly after navigation).
     */
    fun startProcessing(
        templateId: String,
        mediaUris: List<Uri>,
        isVideoList: List<Boolean>
    ) {
        if (_state.value is ProcessingState.InProgress) return  // guard against re-entry

        viewModelScope.launch {
            try {
                val template = TrendTemplateRepository.getById(templateId)
                    ?: throw IllegalArgumentException("Template not found: $templateId")

                _state.value = ProcessingState.InProgress(
                    progress = 0f,
                    stage = "Analyzing beats…"
                )

                val outputDir = File(context.cacheDir, "exports")

                val outputFile = VideoProcessor.process(
                    context       = context,
                    mediaUris     = mediaUris,
                    isVideoList   = isVideoList,
                    beatTimestamps = template.beatTimestamps,
                    outputDir     = outputDir,
                    onProgress    = { progress ->
                        val stage = when {
                            progress < 0.2f -> "Analyzing beats…"
                            progress < 0.5f -> "Syncing media to rhythm…"
                            progress < 0.8f -> "Applying effects…"
                            else            -> "Finalizing your video…"
                        }
                        _state.value = ProcessingState.InProgress(progress = progress, stage = stage)
                    }
                )

                _state.value = ProcessingState.Success(outputPath = outputFile.absolutePath)

            } catch (e: Exception) {
                e.printStackTrace()
                _state.value = ProcessingState.Error(
                    message = e.localizedMessage ?: "An unexpected error occurred during processing."
                )
            }
        }
    }

    fun reset() {
        _state.value = ProcessingState.Idle
    }
}
