package com.aitrendmaker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AITrendMakerApp : Application()
