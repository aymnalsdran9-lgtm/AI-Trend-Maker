package com.aitrendmaker.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

object MediaStoreHelper {

    /**
     * Copies a video file into the public Movies gallery folder using MediaStore.
     * Works on both API 29+ (scoped storage) and below.
     *
     * @return The [Uri] of the inserted gallery item on success, or null on failure.
     */
    suspend fun saveVideoToGallery(
        context: Context,
        sourceFile: File,
        displayName: String = "AITrendMaker_${System.currentTimeMillis()}.mp4"
    ): Uri? = withContext(Dispatchers.IO) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Scoped Storage path (API 29+)
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AITrendMaker")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return@withContext null

                resolver.openOutputStream(uri)?.use { outputStream ->
                    FileInputStream(sourceFile).use { inputStream ->
                        inputStream.copyTo(outputStream, bufferSize = 65_536)
                    }
                }

                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)

                uri
            } else {
                // Legacy path (API < 29)
                val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                val appDir = File(moviesDir, "AITrendMaker").apply { mkdirs() }
                val destFile = File(appDir, displayName)

                FileInputStream(sourceFile).use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output, bufferSize = 65_536)
                    }
                }

                // Notify MediaScanner
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DATA, destFile.absolutePath)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                }
                context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
