package com.aitrendmaker.model

import kotlinx.serialization.Serializable

@Serializable
data class TrendTemplate(
    val id: String,
    val title: String,
    val audioArtist: String,
    val genre: String,
    val bpm: Int,
    val durationSeconds: Int,
    val beatTimestamps: List<Float>,   // seconds at which each beat lands
    val thumbnailUrl: String,
    val audioAssetName: String,        // raw resource name (sans extension)
    val usageCount: String,            // e.g. "2.3M uses"
    val isHot: Boolean = false,
    val accentHex: String = "#7C3AFF"  // per-template brand colour
)

/** Simulated dataset – in production this would come from a backend API. */
object TrendTemplateRepository {

    fun getAll(): List<TrendTemplate> = listOf(
        TrendTemplate(
            id = "template_001",
            title = "Neon Pulse",
            audioArtist = "DJ Aurora",
            genre = "Electronic",
            bpm = 128,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 128, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400",
            audioAssetName = "neon_pulse",
            usageCount = "3.1M",
            isHot = true,
            accentHex = "#7C3AFF"
        ),
        TrendTemplate(
            id = "template_002",
            title = "Golden Hour Vibes",
            audioArtist = "Sunset Collective",
            genre = "Lo-fi Hip Hop",
            bpm = 85,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 85, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1495616811223-4d98c6e9c869?w=400",
            audioAssetName = "golden_hour",
            usageCount = "1.8M",
            isHot = false,
            accentHex = "#FF9500"
        ),
        TrendTemplate(
            id = "template_003",
            title = "Cyber Rush",
            audioArtist = "Synthwave Rider",
            genre = "Synthwave",
            bpm = 140,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 140, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=400",
            audioAssetName = "cyber_rush",
            usageCount = "5.2M",
            isHot = true,
            accentHex = "#00E5FF"
        ),
        TrendTemplate(
            id = "template_004",
            title = "Summer Nostalgia",
            audioArtist = "Wave Chaser",
            genre = "Pop",
            bpm = 105,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 105, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400",
            audioAssetName = "summer_nostalgia",
            usageCount = "900K",
            isHot = false,
            accentHex = "#FF6B6B"
        ),
        TrendTemplate(
            id = "template_005",
            title = "Trap God Remix",
            audioArtist = "BeatSmith X",
            genre = "Hip Hop / Trap",
            bpm = 160,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 160, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400",
            audioAssetName = "trap_god",
            usageCount = "7.4M",
            isHot = true,
            accentHex = "#B8FF00"
        ),
        TrendTemplate(
            id = "template_006",
            title = "Midnight Drive",
            audioArtist = "Lo Rider",
            genre = "Chillhop",
            bpm = 75,
            durationSeconds = 30,
            beatTimestamps = generateBeats(bpm = 75, durationSec = 30),
            thumbnailUrl = "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400",
            audioAssetName = "midnight_drive",
            usageCount = "620K",
            isHot = false,
            accentHex = "#7C3AFF"
        )
    )

    fun getById(id: String): TrendTemplate? = getAll().find { it.id == id }

    /**
     * Generates evenly-spaced beat timestamps at the given BPM.
     * In a production app these would come from a beat-detection service.
     */
    private fun generateBeats(bpm: Int, durationSec: Int): List<Float> {
        val secondsPerBeat = 60f / bpm
        val beats = mutableListOf<Float>()
        var t = 0f
        while (t <= durationSec) {
            beats.add(t)
            t += secondsPerBeat
        }
        return beats
    }
}
