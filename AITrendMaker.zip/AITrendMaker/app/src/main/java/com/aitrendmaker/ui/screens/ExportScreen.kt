package com.aitrendmaker.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitrendmaker.model.ExportState
import com.aitrendmaker.ui.components.*
import com.aitrendmaker.ui.theme.*
import com.aitrendmaker.viewmodel.ExportViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    outputPath: String,
    onBackToHome: () -> Unit,
    viewModel: ExportViewModel = hiltViewModel()
) {
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    val videoUri = remember(outputPath) {
        if (outputPath.isNotBlank() && File(outputPath).exists())
            Uri.parse("file://$outputPath")
        else null
    }

    // Show error messages in snackbar
    LaunchedEffect(exportState) {
        if (exportState is ExportState.Error) {
            snackbarHostState.showSnackbar(
                message = (exportState as ExportState.Error).message,
                duration = SnackbarDuration.Long
            )
            viewModel.dismissError()
        }
    }

    Scaffold(
        snackbarHost = { AppSnackbarHost(snackbarHostState) },
        containerColor = Void,
        topBar = {
            TopAppBar(
                title = {
                    Text("Your Trend is Ready!", style = MaterialTheme.typography.titleLarge, color = OnVoid)
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Void)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // ── Video Preview with watermark ──────────────────────────────
            if (videoUri != null) {
                VideoPreviewWithWatermark(
                    uri = videoUri,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 16f)
                        .clip(RoundedCornerShape(20.dp))
                )
            } else {
                // Placeholder if file not found (shouldn't happen in normal flow)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 16f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(ElevatedInk),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Preview unavailable", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // ── Success badge ─────────────────────────────────────────────
            AnimatedVisibility(
                visible = exportState is ExportState.Saved,
                enter = fadeIn() + slideInVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = SuccessGreen.copy(alpha = 0.12f)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(SuccessGreen.copy(alpha = 0.4f))
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = SuccessGreen)
                        Text(
                            "Saved to your gallery!",
                            style = MaterialTheme.typography.bodyLarge,
                            color = SuccessGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ── Action buttons ────────────────────────────────────────────
            Text(
                text = "Share your creation",
                style = MaterialTheme.typography.titleMedium,
                color = OnVoid
            )

            // Save to Gallery
            val isSaving = exportState is ExportState.Saving
            val isSaved = exportState is ExportState.Saved
            GradientButton(
                text = if (isSaved) "✓  Saved to Gallery" else if (isSaving) "Saving…" else "↓  Save to Gallery",
                onClick = { if (!isSaved && !isSaving) viewModel.saveToGallery(outputPath) },
                enabled = !isSaving && !isSaved,
                modifier = Modifier.fillMaxWidth()
            )

            // Platform share row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SocialShareButton(
                    label = "TikTok",
                    icon = Icons.Default.VideoLibrary,
                    color = Color(0xFFFF0050),
                    onClick = { viewModel.shareToTikTok(outputPath) },
                    modifier = Modifier.weight(1f)
                )
                SocialShareButton(
                    label = "Instagram",
                    icon = Icons.Default.CameraAlt,
                    color = Color(0xFFE1306C),
                    onClick = { viewModel.shareToInstagram(outputPath) },
                    modifier = Modifier.weight(1f)
                )
                SocialShareButton(
                    label = "Share",
                    icon = Icons.Default.Share,
                    color = NeonCyan,
                    onClick = { viewModel.shareGeneric(outputPath) },
                    modifier = Modifier.weight(1f)
                )
            }

            // ── Make another trend ────────────────────────────────────────
            OutlinedButton(
                onClick = onBackToHome,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = androidx.compose.ui.graphics.SolidColor(Muted.copy(alpha = 0.3f))
                )
            ) {
                Icon(Icons.Default.Home, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Make Another Trend")
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SocialShareButton(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = androidx.compose.ui.graphics.SolidColor(color.copy(alpha = 0.4f))
        ),
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelLarge)
    }
}
