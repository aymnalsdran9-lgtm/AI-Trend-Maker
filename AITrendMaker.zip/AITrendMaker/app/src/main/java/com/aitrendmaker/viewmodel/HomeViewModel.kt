package com.aitrendmaker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitrendmaker.model.TrendTemplate
import com.aitrendmaker.model.TrendTemplateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val templates: List<TrendTemplate> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val selectedFilter: String = "All"
)

@HiltViewModel
class HomeViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState(isLoading = true))
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val filters = listOf("All", "🔥 Hot", "Electronic", "Hip Hop", "Pop", "Lo-fi")

    init {
        loadTemplates()
    }

    private fun loadTemplates() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
                // Simulate network latency
                delay(600)
                val templates = TrendTemplateRepository.getAll()
                _uiState.value = _uiState.value.copy(
                    templates = templates,
                    isLoading = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Failed to load trends: ${e.localizedMessage}"
                )
            }
        }
    }

    fun setFilter(filter: String) {
        val allTemplates = TrendTemplateRepository.getAll()
        val filtered = when (filter) {
            "🔥 Hot" -> allTemplates.filter { it.isHot }
            "All"    -> allTemplates
            else     -> allTemplates.filter { it.genre.contains(filter, ignoreCase = true) }
        }
        _uiState.value = _uiState.value.copy(
            selectedFilter = filter,
            templates = filtered
        )
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun refresh() = loadTemplates()
}
