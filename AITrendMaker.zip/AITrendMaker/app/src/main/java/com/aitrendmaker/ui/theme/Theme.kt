package com.aitrendmaker.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.compose.material3.Typography

// ── Palette ───────────────────────────────────────────────────────────────────
// Deep black canvas with electric violet primary and acid-lime accent.
// One risk: the gradient-glow "pulse" signature element on cards – distinct
// from the typical acid-green-on-black default because violet is the lead colour.
val Void         = Color(0xFF080810)   // near-black background
val DeepInk      = Color(0xFF0F0F1E)   // surface
val ElevatedInk  = Color(0xFF16162A)   // elevated surface
val CardInk      = Color(0xFF1C1C30)   // card background

val ElectricViolet = Color(0xFF7C3AFF) // primary brand
val VioletGlow     = Color(0xFFAB71FF) // primary container / lighter
val AcidLime       = Color(0xFFB8FF00) // accent / tertiary – "trending" energy
val NeonCyan       = Color(0xFF00E5FF) // secondary highlight

val OnVoid       = Color(0xFFF0EEFF)   // on-background text
val OnDeepInk    = Color(0xFFE8E4FF)   // on-surface text
val Muted        = Color(0xFF6B6B8A)   // secondary text / outlines

val ErrorRed     = Color(0xFFFF4D6A)
val SuccessGreen = Color(0xFF00D68F)

private val DarkColorScheme = darkColorScheme(
    primary            = ElectricViolet,
    onPrimary          = Color.White,
    primaryContainer   = VioletGlow.copy(alpha = 0.25f),
    onPrimaryContainer = VioletGlow,
    secondary          = NeonCyan,
    onSecondary        = Void,
    secondaryContainer = NeonCyan.copy(alpha = 0.15f),
    onSecondaryContainer = NeonCyan,
    tertiary           = AcidLime,
    onTertiary         = Void,
    tertiaryContainer  = AcidLime.copy(alpha = 0.15f),
    onTertiaryContainer = AcidLime,
    background         = Void,
    onBackground       = OnVoid,
    surface            = DeepInk,
    onSurface          = OnDeepInk,
    surfaceVariant     = ElevatedInk,
    onSurfaceVariant   = Muted,
    surfaceTint        = ElectricViolet,
    outline            = Muted.copy(alpha = 0.5f),
    error              = ErrorRed,
    onError            = Color.White,
)

// ── Typography ────────────────────────────────────────────────────────────────
// System default sans-serif; bold headline weights feel native and fast
private val AppTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Black,
        fontSize = 48.sp,
        lineHeight = 52.sp,
        letterSpacing = (-1.5).sp
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.ExtraBold,
        fontSize = 36.sp,
        lineHeight = 40.sp,
        letterSpacing = (-1).sp
    ),
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.4.sp
    )
)

@Composable
fun AITrendMakerTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Void.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = AppTypography,
        content     = content
    )
}
