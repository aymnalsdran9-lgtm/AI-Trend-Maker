package com.aitrendmaker.model

import android.net.Uri

/** Represents a piece of user-selected media (photo or video). */
data class MediaItem(
    val uri: Uri,
    val isVideo: Boolean,
    val durationMs: Long = 0L  // only meaningful for video
)

/** Tracks the overall beat-sync processing state. */
sealed class ProcessingState {
    data object Idle : ProcessingState()
    data class InProgress(val progress: Float, val stage: String) : ProcessingState()
    data class Success(val outputPath: String) : ProcessingState()
    data class Error(val message: String) : ProcessingState()
}

/** Tracks gallery-save / export state. */
sealed class ExportState {
    data object Idle : ExportState()
    data object Saving : ExportState()
    data class Saved(val uri: Uri) : ExportState()
    data class Error(val message: String) : ExportState()
}
