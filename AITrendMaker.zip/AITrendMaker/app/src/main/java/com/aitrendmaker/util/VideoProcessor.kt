package com.aitrendmaker.util

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val TAG = "VideoProcessor"

object VideoProcessor {

    /**
     * Builds a beat-synced video using Media3 Transformer.
     *
     * For each beat window we trim either a video clip or generate a static
     * image clip (via a single-frame video if the media is a photo). The
     * resulting clips are concatenated in sequence.
     *
     * [mediaUris]      – ordered list of user-selected photo/video URIs.
     * [beatTimestamps] – beat timestamps in seconds from the template.
     * [outputDir]      – directory to write the output mp4 into.
     * [onProgress]     – callback with 0..1 progress.
     *
     * Returns the [File] pointing to the exported mp4.
     */
    suspend fun process(
        context: Context,
        mediaUris: List<Uri>,
        isVideoList: List<Boolean>,
        beatTimestamps: List<Float>,
        outputDir: File,
        onProgress: suspend (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        require(mediaUris.isNotEmpty()) { "No media selected" }
        require(beatTimestamps.size >= 2) { "Need at least two beat timestamps" }

        outputDir.mkdirs()
        val outputFile = File(outputDir, "trend_${System.currentTimeMillis()}.mp4")

        // Build EditedMediaItems: one per beat window, cycling through user media.
        val editedItems = mutableListOf<EditedMediaItem>()

        for (i in 0 until beatTimestamps.size - 1) {
            val startUs = (beatTimestamps[i] * 1_000_000).toLong()
            val endUs   = (beatTimestamps[i + 1] * 1_000_000).toLong()
            val durationUs = endUs - startUs
            if (durationUs <= 0L) continue

            val mediaIndex = i % mediaUris.size
            val uri = mediaUris[mediaIndex]
            val isVideo = isVideoList[mediaIndex]

            val mediaItem = if (isVideo) {
                // Trim the video to the beat window
                MediaItem.Builder()
                    .setUri(uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0L)          // always clip from start for simplicity
                            .setEndPositionMs(durationUs / 1000)
                            .build()
                    )
                    .build()
            } else {
                // Photos: display each photo for the beat duration
                MediaItem.Builder()
                    .setUri(uri)
                    .setImageDurationMs(durationUs / 1000)
                    .build()
            }

            editedItems.add(EditedMediaItem.Builder(mediaItem).build())
        }

        if (editedItems.isEmpty()) {
            throw IllegalStateException("No valid media clips could be built from the selection")
        }

        // Report initial progress
        onProgress(0.05f)

        // Use suspendCancellableCoroutine so the caller coroutine propagates cancellation
        suspendCancellableCoroutine { continuation ->
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        Log.d(TAG, "Export complete: ${outputFile.absolutePath}")
                        continuation.resume(outputFile)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        Log.e(TAG, "Export error", exportException)
                        continuation.resumeWithException(exportException)
                    }
                })
                .build()

            val sequence = EditedMediaItemSequence(editedItems)
            val composition = Composition.Builder(listOf(sequence)).build()

            continuation.invokeOnCancellation { transformer.cancel() }
            transformer.start(composition, outputFile.absolutePath)

            // Poll Transformer progress on a background loop until the coroutine resumes
            val progressHolder = ProgressHolder()
            val pollingJob = kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
                while (continuation.isActive) {
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(0.05f + (progressHolder.progress / 100f) * 0.90f)
                    }
                    delay(150)
                }
            }
            continuation.invokeOnCancellation { pollingJob.cancel() }
        }
    }
}
