package com.aitrendmaker

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.aitrendmaker.ui.screens.EditorScreen
import com.aitrendmaker.ui.screens.ExportScreen
import com.aitrendmaker.ui.screens.HomeScreen
import com.aitrendmaker.ui.screens.ProcessingScreen
import com.aitrendmaker.ui.screens.SelectedMediaHolder

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Editor : Screen("editor/{templateId}") {
        fun createRoute(templateId: String) = "editor/$templateId"
    }
    data object Processing : Screen("processing/{templateId}") {
        fun createRoute(templateId: String) = "processing/$templateId"
    }
    data object Export : Screen("export/{outputPath}") {
        fun createRoute(outputPath: String) = "export/${outputPath.encodeUrlSafe()}"
    }
}

fun String.encodeUrlSafe(): String = java.net.URLEncoder.encode(this, "UTF-8")
fun String.decodeUrlSafe(): String = java.net.URLDecoder.decode(this, "UTF-8")

@Composable
fun AppNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onTemplateSelected = { templateId ->
                    navController.navigate(Screen.Editor.createRoute(templateId))
                }
            )
        }

        composable(
            route = Screen.Editor.route,
            arguments = listOf(navArgument("templateId") { type = NavType.StringType })
        ) { backStackEntry ->
            val templateId = backStackEntry.arguments?.getString("templateId") ?: ""
            EditorScreen(
                templateId = templateId,
                onSyncClicked = { tplId ->
                    navController.navigate(Screen.Processing.createRoute(tplId))
                },
                onBackClicked = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Processing.route,
            arguments = listOf(navArgument("templateId") { type = NavType.StringType })
        ) { backStackEntry ->
            val templateId = backStackEntry.arguments?.getString("templateId") ?: ""
            ProcessingScreen(
                templateId = templateId,
                onProcessingComplete = { outputPath ->
                    navController.navigate(Screen.Export.createRoute(outputPath)) {
                        popUpTo(Screen.Home.route)
                    }
                },
                onError = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = Screen.Export.route,
            arguments = listOf(navArgument("outputPath") { type = NavType.StringType })
        ) { backStackEntry ->
            val outputPath = backStackEntry.arguments?.getString("outputPath")?.decodeUrlSafe() ?: ""
            ExportScreen(
                outputPath = outputPath,
                onBackToHome = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                    }
                }
            )
        }
    }
}
