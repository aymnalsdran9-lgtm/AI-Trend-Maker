package com.aitrendmaker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aitrendmaker.model.ExportState
import com.aitrendmaker.util.MediaStoreHelper
import com.aitrendmaker.util.ShareHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ExportViewModel @Inject constructor(
    application: Application
) : AndroidViewModel(application) {

    private val _exportState = MutableStateFlow<ExportState>(ExportState.Idle)
    val exportState: StateFlow<ExportState> = _exportState.asStateFlow()

    private val context get() = getApplication<Application>().applicationContext

    /** Copies the rendered video into the device gallery via MediaStore. */
    fun saveToGallery(outputPath: String) {
        viewModelScope.launch {
            try {
                _exportState.value = ExportState.Saving
                val file = File(outputPath)
                if (!file.exists()) {
                    _exportState.value = ExportState.Error("Output file not found.")
                    return@launch
                }
                val savedUri = MediaStoreHelper.saveVideoToGallery(context, file)
                if (savedUri != null) {
                    _exportState.value = ExportState.Saved(savedUri)
                } else {
                    _exportState.value = ExportState.Error("Could not save to gallery. Check storage permissions.")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _exportState.value = ExportState.Error(
                    e.localizedMessage ?: "Save failed due to an unknown error."
                )
            }
        }
    }

    fun shareGeneric(outputPath: String) {
        try {
            ShareHelper.shareVideo(context, File(outputPath))
        } catch (e: Exception) {
            _exportState.value = ExportState.Error("Unable to open share sheet: ${e.localizedMessage}")
        }
    }

    fun shareToTikTok(outputPath: String) {
        try {
            ShareHelper.shareToTikTok(context, File(outputPath))
        } catch (e: Exception) {
            _exportState.value = ExportState.Error("Unable to open TikTok: ${e.localizedMessage}")
        }
    }

    fun shareToInstagram(outputPath: String) {
        try {
            ShareHelper.shareToInstagram(context, File(outputPath))
        } catch (e: Exception) {
            _exportState.value = ExportState.Error("Unable to open Instagram: ${e.localizedMessage}")
        }
    }

    fun dismissError() {
        _exportState.value = ExportState.Idle
    }
}
