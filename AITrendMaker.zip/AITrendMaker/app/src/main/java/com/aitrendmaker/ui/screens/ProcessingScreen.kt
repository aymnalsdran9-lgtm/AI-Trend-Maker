package com.aitrendmaker.ui.screens

import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitrendmaker.model.ProcessingState
import com.aitrendmaker.ui.theme.*
import com.aitrendmaker.viewmodel.ProcessingViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// In a real app the list of selected URIs would be passed via a shared ViewModel or
// SavedStateHandle. For this MVP we retrieve them from a companion object populated
// by EditorScreen before navigation (simpler than parcelable URI lists through navargs).
object SelectedMediaHolder {
    var uris: List<Uri> = emptyList()
    var isVideoList: List<Boolean> = emptyList()
}

@Composable
fun ProcessingScreen(
    templateId: String,
    onProcessingComplete: (String) -> Unit,
    onError: () -> Unit,
    viewModel: ProcessingViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // Kick off processing once
    LaunchedEffect(templateId) {
        viewModel.startProcessing(
            templateId = templateId,
            mediaUris = SelectedMediaHolder.uris,
            isVideoList = SelectedMediaHolder.isVideoList
        )
    }

    // React to terminal states
    LaunchedEffect(state) {
        when (val s = state) {
            is ProcessingState.Success -> onProcessingComplete(s.outputPath)
            is ProcessingState.Error   -> onError()
            else -> Unit
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Void),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(32.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            // Compose-native beat-pulse animation (replaces Lottie dependency)
            BeatPulseAnimation(modifier = Modifier.size(180.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "AI Analyzing Beats\n& Syncing Media…",
                    style = MaterialTheme.typography.headlineMedium,
                    color = OnVoid,
                    textAlign = TextAlign.Center
                )

                val stage = (state as? ProcessingState.InProgress)?.stage ?: "Preparing…"
                AnimatedStageText(stage = stage)
            }

            // Progress bar
            val progress = (state as? ProcessingState.InProgress)?.progress ?: 0f
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = ElectricViolet,
                    trackColor = ElevatedInk
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                    color = VioletGlow,
                    fontWeight = FontWeight.Bold
                )
            }

            // Error state feedback
            if (state is ProcessingState.Error) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ErrorRed.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = (state as ProcessingState.Error).message,
                        color = ErrorRed,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/** Orbiting dots that pulse to represent beat analysis. */
@Composable
fun BeatPulseAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "beat_anim")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "rotation"
    )

    val innerScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(700, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "inner_scale"
    )

    val outerAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "outer_alpha"
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing ring
        Box(
            modifier = Modifier
                .fillMaxSize(0.9f)
                .alpha(outerAlpha * 0.3f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(ElectricViolet.copy(alpha = 0.4f), Color.Transparent)
                    )
                )
        )

        // Orbiting dots canvas
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val centerX = size.width / 2
            val centerY = size.height / 2
            val orbitRadius = size.minDimension * 0.38f
            val dotCount = 8

            repeat(dotCount) { i ->
                val angle = (rotation + i * (360f / dotCount)) * (PI / 180f).toFloat()
                val x = centerX + orbitRadius * cos(angle)
                val y = centerY + orbitRadius * sin(angle)
                val dotAlpha = 0.3f + (0.7f * ((i.toFloat() / dotCount)))
                val dotRadius = 6.dp.toPx() * (0.6f + 0.4f * dotAlpha)

                drawCircle(
                    color = ElectricViolet,
                    radius = dotRadius,
                    center = Offset(x, y),
                    alpha = dotAlpha
                )
            }

            // Inner ring (counter-rotating)
            val innerOrbit = orbitRadius * 0.55f
            repeat(5) { i ->
                val angle = (-rotation * 1.5f + i * 72f) * (PI / 180f).toFloat()
                val x = centerX + innerOrbit * cos(angle)
                val y = centerY + innerOrbit * sin(angle)
                drawCircle(
                    color = AcidLime,
                    radius = 4.dp.toPx(),
                    center = Offset(x, y),
                    alpha = 0.7f
                )
            }
        }

        // Centre icon
        Box(
            modifier = Modifier
                .size(60.dp)
                .scale(innerScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(ElectricViolet, ElectricViolet.copy(alpha = 0.7f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
private fun AnimatedStageText(stage: String) {
    val alpha by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(400),
        label = "stage_alpha"
    )
    Text(
        text = stage,
        style = MaterialTheme.typography.bodyLarge,
        color = Muted.copy(alpha = alpha),
        textAlign = TextAlign.Center,
        modifier = Modifier.alpha(alpha)
    )
}
