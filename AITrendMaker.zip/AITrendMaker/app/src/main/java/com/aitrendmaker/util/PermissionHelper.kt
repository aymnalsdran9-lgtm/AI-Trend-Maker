package com.aitrendmaker.util

import android.os.Build

object PermissionHelper {

    /** Returns the set of media permissions required on the current API level. */
    fun requiredMediaPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // API 33+ – granular media permissions
            arrayOf(
                android.Manifest.permission.READ_MEDIA_IMAGES,
                android.Manifest.permission.READ_MEDIA_VIDEO,
                android.Manifest.permission.READ_MEDIA_AUDIO
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // API 29-32 – READ_EXTERNAL_STORAGE (WRITE not needed with scoped storage)
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            // API 26-28 – both READ and WRITE
            arrayOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
    }
}
