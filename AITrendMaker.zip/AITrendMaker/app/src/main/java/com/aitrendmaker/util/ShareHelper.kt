package com.aitrendmaker.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object ShareHelper {

    private fun getShareUri(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /** Opens a system share sheet for the output video. */
    fun shareVideo(context: Context, videoFile: File) {
        val uri = getShareUri(context, videoFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Created with AI Trend Maker 🎵✨ #AITrendMaker #Trending")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share your trend").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    /** Attempts to open TikTok directly; falls back to the generic share sheet. */
    fun shareToTikTok(context: Context, videoFile: File) {
        val uri = getShareUri(context, videoFile)
        val tiktokIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            `package` = "com.zhiliaoapp.musically"  // TikTok package
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val isInstalled = context.packageManager.queryIntentActivities(tiktokIntent, 0).isNotEmpty()
        if (isInstalled) {
            context.startActivity(tiktokIntent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        } else {
            shareVideo(context, videoFile)
        }
    }

    /** Attempts to open Instagram Reels directly; falls back to the generic share sheet. */
    fun shareToInstagram(context: Context, videoFile: File) {
        val uri = getShareUri(context, videoFile)
        val igIntent = Intent("com.instagram.share.ADD_TO_REEL").apply {
            `package` = "com.instagram.android"
            putExtra("interactive_asset_uri", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val isInstalled = context.packageManager.queryIntentActivities(igIntent, 0).isNotEmpty()
        if (isInstalled) {
            context.startActivity(igIntent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        } else {
            shareVideo(context, videoFile)
        }
    }
}
