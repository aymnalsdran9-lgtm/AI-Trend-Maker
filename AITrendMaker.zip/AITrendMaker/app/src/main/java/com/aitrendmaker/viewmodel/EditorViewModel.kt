package com.aitrendmaker.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import com.aitrendmaker.model.MediaItem
import com.aitrendmaker.model.TrendTemplate
import com.aitrendmaker.model.TrendTemplateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

data class EditorUiState(
    val template: TrendTemplate? = null,
    val selectedMedia: List<MediaItem> = emptyList(),
    val previewUri: Uri? = null,
    val isVideoPreview: Boolean = false,
    val errorMessage: String? = null,
    val canProceed: Boolean = false
)

@HiltViewModel
class EditorViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    fun loadTemplate(templateId: String) {
        val template = TrendTemplateRepository.getById(templateId)
        _uiState.value = _uiState.value.copy(template = template)
    }

    fun onMediaSelected(uris: List<Uri>, isVideoList: List<Boolean>) {
        if (uris.isEmpty()) return
        val items = uris.mapIndexed { index, uri ->
            MediaItem(uri = uri, isVideo = isVideoList.getOrElse(index) { false })
        }
        _uiState.value = _uiState.value.copy(
            selectedMedia = items,
            previewUri = uris.first(),
            isVideoPreview = isVideoList.firstOrNull() ?: false,
            canProceed = true,
            errorMessage = null
        )
    }

    fun onSingleMediaSelected(uri: Uri, isVideo: Boolean) {
        onMediaSelected(listOf(uri), listOf(isVideo))
    }

    fun removeMediaAt(index: Int) {
        val updated = _uiState.value.selectedMedia.toMutableList().also { it.removeAt(index) }
        val newPreview = updated.firstOrNull()
        _uiState.value = _uiState.value.copy(
            selectedMedia = updated,
            previewUri = newPreview?.uri,
            isVideoPreview = newPreview?.isVideo ?: false,
            canProceed = updated.isNotEmpty()
        )
    }

    fun setPreview(index: Int) {
        val media = _uiState.value.selectedMedia.getOrNull(index) ?: return
        _uiState.value = _uiState.value.copy(
            previewUri = media.uri,
            isVideoPreview = media.isVideo
        )
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
