package com.aitrendmaker.ui.screens

import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.aitrendmaker.ui.components.*
import com.aitrendmaker.ui.theme.*
import com.aitrendmaker.util.PermissionHelper
import com.aitrendmaker.viewmodel.EditorViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun EditorScreen(
    templateId: String,
    onSyncClicked: (String) -> Unit,
    onBackClicked: () -> Unit,
    viewModel: EditorViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    // Permissions state
    val permissions = remember { PermissionHelper.requiredMediaPermissions().toList() }
    val permissionsState = rememberMultiplePermissionsState(permissions = permissions)
    var showPermissionRationale by rememberSaveable { mutableStateOf(false) }

    // Photo picker – multi-select
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris ->
        if (uris.isNotEmpty()) {
            val isVideoList = uris.map { uri ->
                val type = context.contentResolver.getType(uri) ?: ""
                type.startsWith("video/")
            }
            viewModel.onMediaSelected(uris, isVideoList)
        }
    }

    LaunchedEffect(templateId) {
        viewModel.loadTemplate(templateId)
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Long)
            viewModel.dismissError()
        }
    }

    if (showPermissionRationale) {
        PermissionRationaleDialog(
            onConfirm = {
                showPermissionRationale = false
                permissionsState.launchMultiplePermissionRequest()
            },
            onDismiss = { showPermissionRationale = false }
        )
    }

    Scaffold(
        snackbarHost = { AppSnackbarHost(snackbarHostState) },
        containerColor = Void,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = uiState.template?.title ?: "Edit",
                        style = MaterialTheme.typography.titleLarge,
                        color = OnVoid,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClicked) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = OnVoid)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Void)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ── Template info card ────────────────────────────────────────
            uiState.template?.let { template ->
                TemplateInfoCard(
                    title = template.title,
                    artist = template.audioArtist,
                    bpm = template.bpm,
                    duration = template.durationSeconds,
                    beatCount = template.beatTimestamps.size
                )
            }

            // ── Media Preview ─────────────────────────────────────────────
            MediaPreviewSection(
                previewUri = uiState.previewUri,
                isVideo = uiState.isVideoPreview
            )

            // ── Selected media thumbnail strip ────────────────────────────
            AnimatedVisibility(
                visible = uiState.selectedMedia.isNotEmpty(),
                enter = fadeIn() + slideInVertically()
            ) {
                SelectedMediaStrip(
                    mediaItems = uiState.selectedMedia.map { it.uri },
                    onItemClick = viewModel::setPreview,
                    onItemRemove = viewModel::removeMediaAt
                )
            }

            // ── Pick media button ─────────────────────────────────────────
            OutlinedButton(
                onClick = {
                    if (permissionsState.allPermissionsGranted) {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                        )
                    } else if (permissionsState.shouldShowRationale) {
                        showPermissionRationale = true
                    } else {
                        permissionsState.launchMultiplePermissionRequest()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = VioletGlow),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = androidx.compose.ui.graphics.SolidColor(ElectricViolet.copy(alpha = 0.5f))
                )
            ) {
                Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (uiState.selectedMedia.isEmpty()) "Pick Photos / Videos"
                    else "Change Selection (${uiState.selectedMedia.size} selected)"
                )
            }

            // ── Sync to Beat CTA ──────────────────────────────────────────
            GradientButton(
                text = "✦  Sync to Beat",
                onClick = {
                    // Populate the shared holder before navigation
                    SelectedMediaHolder.uris = uiState.selectedMedia.map { it.uri }
                    SelectedMediaHolder.isVideoList = uiState.selectedMedia.map { it.isVideo }
                    onSyncClicked(templateId)
                },
                enabled = uiState.canProceed,
                modifier = Modifier.fillMaxWidth()
            )

            if (!uiState.canProceed) {
                Text(
                    text = "Select at least one photo or video to continue.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Muted,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun TemplateInfoCard(
    title: String,
    artist: String,
    bpm: Int,
    duration: Int,
    beatCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ElevatedInk),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(ElectricViolet.copy(alpha = 0.25f))
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ElectricViolet.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MusicNote, null, tint = ElectricViolet, modifier = Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = OnDeepInk)
                Text(artist, style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                GlowBadge("$bpm BPM", ElectricViolet)
                Text("${duration}s · $beatCount cuts", style = MaterialTheme.typography.labelSmall, color = Muted)
            }
        }
    }
}

@Composable
private fun MediaPreviewSection(previewUri: android.net.Uri?, isVideo: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(16.dp))
            .background(ElevatedInk),
        contentAlignment = Alignment.Center
    ) {
        if (previewUri != null) {
            if (isVideo) {
                VideoPlayerView(uri = previewUri, modifier = Modifier.fillMaxSize())
            } else {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(previewUri)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Preview",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.VideoLibrary,
                    contentDescription = null,
                    tint = Muted,
                    modifier = Modifier.size(48.dp)
                )
                Text("Your media preview", style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
        }
    }
}

@Composable
private fun SelectedMediaStrip(
    mediaItems: List<Uri>,
    onItemClick: (Int) -> Unit,
    onItemRemove: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Selected media",
            style = MaterialTheme.typography.labelLarge,
            color = Muted
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(mediaItems) { index, uri ->
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, ElectricViolet.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                        .clickable { onItemClick(index) }
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(uri)
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // Remove button
                    IconButton(
                        onClick = { onItemRemove(index) },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.7f))
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Remove",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    // Index label
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(3.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(3.dp)
                    ) {
                        Text(
                            "${index + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRationaleDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ElevatedInk,
        title = { Text("Media Access Required", color = OnDeepInk) },
        text = {
            Text(
                "AI Trend Maker needs access to your photos and videos to create beat-synced clips. " +
                        "Please grant media permissions to continue.",
                color = Muted
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Allow", color = ElectricViolet, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) }
        }
    )
}
